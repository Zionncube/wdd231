// Hamburger Menu Toggle
const menuToggle = document.getElementById('menu-toggle');
const mainNav = document.getElementById('main-nav');

menuToggle.addEventListener('click', () => {
    mainNav.classList.toggle('open');
    menuToggle.classList.toggle('open');
});

// Dynamic Year for Footer
document.getElementById('year').textContent = new Date().getFullYear();

// Last Modified Date
document.getElementById('last-modified').textContent = document.lastModified;

// Form Display on Thank You Page (if form.html uses GET method)
function displayFormData() {
    const params = new URLSearchParams(window.location.search);
    const name = params.get("fname");
    if (name) {
        const message = document.getElementById("thankYouMessage");
        message.innerHTML = `<h2>Thank you, ${name}!</h2><p>Your submission has been received.</p>`;
    }
}

document.querySelector("form").addEventListener("submit", function(e) {
    const username = document.getElementById("username").value;
    localStorage.setItem("username", username);
  });

  const spotlightVideos = [
    { title: "The Power of I AM", url: "https://www.youtube.com/embed/z8O7I__J97Y" },
    { title: "Master Key Society: Mental Mastery", url: "https://www.youtube.com/embed/YbWYy9AqVtE" },
    { title: "Napoleon Hill Audiobook", url: "https://www.youtube.com/embed/UhCt6P6lv_U" },
  ];
  
  const videoOfWeek = spotlightVideos[new Date().getWeekNumber() % spotlightVideos.length]; // rotate weekly
  
  document.getElementById("spotlight-video").innerHTML = `
    <h3>${videoOfWeek.title}</h3>
    <iframe src="${videoOfWeek.url}" frameborder="0" allowfullscreen loading="lazy"></iframe>
  `;
  
  // Helper function to get week number
  Date.prototype.getWeekNumber = function () {
    const firstJan = new Date(this.getFullYear(), 0, 1);
    return Math.ceil((((this - firstJan) / 86400000) + firstJan.getDay() + 1) / 7);
  };

  document.querySelectorAll(".resource-card .more-info").forEach(btn => {
    btn.addEventListener("click", () => {
      const title = btn.dataset.title;
      const desc = btn.dataset.desc;
      document.getElementById("modal-title").textContent = title;
      document.getElementById("modal-description").textContent = desc;
      document.getElementById("modal").classList.remove("hidden");
    });
  });
  
  document.querySelector(".close-btn").addEventListener("click", () => {
    document.getElementById("modal").classList.add("hidden");
  });
  

document.addEventListener("DOMContentLoaded", () => {
    displayFormData();
});
